/*
*  Written by Mimo on 01-Oct-2017
*
*  CONTEXT	: Preparation of a revisited TERRAMASTER utility to download FLIGHTGear Scenery data
*  PURPOSE	: Understanding the TerraMaster architecture while building a FXML MMI
*  ROLE	: Common Memory to support synchronisation operations using a separate thread
*  ---------------
*   Notes : Designed to synchronize operations between GUI driven activities (on the FX-Thread) and a single Worker Thread.
*/

package javwep.mimo.gardeningThread;


import appPropertyPKG.AppPropertiesMgr;
import java.net.URL;
import java.nio.file.Path;
import javafx.application.Platform;
import javwep.mimo.gardenAccessMain.GardenAccessCTRL;
import javwep.mimo.gardeningObjects.GridCell;
import javwep.mimo.gardeningObjects.GridCellMatrix;
import modalThreadingPKG.MThreadActions;
import modalThreadingPKG.MThreadPilot;
import modalThreadingPKG.MThreadStates;
import toolExceptionPKG.ToolException;



public class SyncPilot extends MThreadPilot
 {
   // Private Resources
   private final SyncWorker threadWorker;

   // public resources which are FIXED DURING THE WHOLE LIFE CYCLE OF THE SYNCHRONIZER (Set in Constructor)
   private final GardenAccessCTRL ctrlClerc;
   public volatile SyncMissions wrkMission;

   // Public resources which are FIXED DURING ONE SYNCHRONISING TASK
   public URL synchroSource;				// The root of the selected remote Terrasync Server
   public Path localTerraRootPath;			// The root of the selected local Terrasync Repository
   public GridCellMatrix selectedTilesMatrix;	// The GridBoxMatrix with Task candidates
   public GridCell tempRegionCell;			// A generic GridCell, initialized for the current Region...

   // Synchro Flags
   public int intermediateCount, checkOutcome;



// wwwwwwwwwwwwwwwwwwwwwwwwwww
//		MAINPROGRAMSECTION  0 -  CONSTRUCTION, INITIALIZATION, and TERMINATION
// wwwwwwwwwwwwwwwwwwwwwwwwwww

   // CONSTRUCTION
   //
   public SyncPilot( GardenAccessCTRL theCtrl, AppPropertiesMgr theConfig )
    {
	super();
	ctrlClerc = theCtrl;
	threadWorker = new SyncWorker(this, theConfig);
	wrkMission = SyncMissions.NONE;
   }



// wwwwwwwwwwwwwwwwwwwwwwwwwww
//		MAINPROGRAMSECTION  1 - Start, or Abort a Mission
// wwwwwwwwwwwwwwwwwwwwwwwwwww

   // Start a Mission if not already Buzy (Thread will not run two Missions in parallel !)
   //
   public synchronized void startNewMission() throws ToolException
    {
	if ( wrkState == MThreadStates.NULL_STATE ) {
	   if ( launchWorkerThread(threadWorker) != MThreadStates.IDLE_STATE) {
		throw new ToolException(workerNotice);
	   }
	}
	if ( ! missionISStarted() ) {
	   throw new ToolException(workerNotice);
	}
   }


   // Abort the current Mission at next checkpoint...
   //
   public synchronized void abortCurrentMission()
    {
	if ( wrkState == MThreadStates.BUZY_STATE || wrkState == MThreadStates.MANDATED_STATE || wrkState == MThreadStates.WAITING_STATE ) {
	   wrkAction = MThreadActions.ABORT_MISSION;
      }
   }


// wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww
//				   MAINPROGRAMSECTION  1 - REPORT TO GUI
// wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww

   // Reporting state and score of the Align Task
   //
   public void reportSyncRunningState()
    {
	workerResult = MThreadStates.MANDATED_STATE;
	workerNotice = "Mission just started...";
	// To be run on the FX Thread ! ... allowing for display time...
	Platform.runLater( ctrlClerc::reportDownloadProgress);
	getAPauseOf(200);
   }

   public void reportSyncProgress()
    {
	workerResult = MThreadStates.BUZY_STATE;
//	workerNotice = "Processing Tile " + scannedItemCount + " ; Updated: " + updatedItemCount + " ; Downloaded Items: " + intermediateCount;
	workerNotice = "Processing Tile " + scannedItemCount + " ; Downloaded Items till now: " + intermediateCount;
	// To be run on the FX Thread !
	Platform.runLater( ctrlClerc::reportDownloadProgress);
   }

   public void reportSyncCompletedState()
    {
	workerNotice = "Mission did succeed; Updated Tiles: " + scannedItemCount + " / Downloaded Items: " + updatedItemCount;
	notify(workerNotice, 20);
	workerResult = MThreadStates.DONE_STATE;
	// To be run on the FX Thread !
	Platform.runLater( ctrlClerc::reportDownloadProgress);

    }

   public void reportSyncAbortedState()
    {
	workerNotice = "Mission aborted, or unable to proceed (Check Network connection?); retry later...";
	notifyAlert(workerNotice, 20);
	workerResult = MThreadStates.ABORTED_STATE;
	// To be run on the FX Thread !
	Platform.runLater( ctrlClerc::reportDownloadProgress);
   }

   public void reportSyncCrashedState()
    {
	workerNotice = "Mission ended with fatal errors : " + totalErrorsCount;
	notifyAlert(workerNotice, 20);
	workerResult = MThreadStates.CRASHED_STATE;
	// To be run on the FX Thread !
	Platform.runLater( ctrlClerc::reportDownloadProgress);
    }

   // Two next have their Notice written in the processing method...
   public void reportClearCompletedState()
    {
	notify(workerNotice, 20);
	workerResult = MThreadStates.DONE_STATE;
	// To be run on the FX Thread !
	Platform.runLater( ctrlClerc::reportClearTermination );
    }

   public void reportSyncObjCompletedState()
    {
	notify(workerNotice, 20);
	workerResult = MThreadStates.DONE_STATE;
	// To be run on the FX Thread !
	Platform.runLater( ctrlClerc::reportSyncObjectsTermination );
    }




// wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww
//				   MAINPROGRAMSECTION  2 - NOTIFICATIONS
// wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww

   // Notifications and choices template : to be defined in the extension
   //	   Note: the message (theNote)  is passed through trdTaskNotice; theMaxDelay is expected in SECONDS

   // Post a paused message
   public int notify( String theMessage, int theMaxDelay )
    {
	if ( ! runLaterFlagISOurs( theMaxDelay ) ) { return -1;	}

	workerNotice = theMessage;
	// To be run on the FX Thread !
	Platform.runLater(ctrlClerc::notifyDownloadMessage);

	// Now wait for the release of the Flag by the FX Thread, until the delay expires
	return waitForFlagRelease(theMaxDelay);
   }

   // Post an Alert Message
   public int notifyAlert( String theMessage, int theMaxDelay )
    {
	if ( ! runLaterFlagISOurs( theMaxDelay ) ) { return -1;	}

	workerNotice = theMessage;
	// To be run on the FX Thread !
	Platform.runLater(ctrlClerc::notifyDownloadAlertMessage);

	// Now wait for the release of the Flag by the FX Thread, until the delay expires
	return waitForFlagRelease(theMaxDelay);
   }

   // Post a Fatal Message
   public int notifyFatal( String theMessage, int theMaxDelay )
    {
	if ( ! runLaterFlagISOurs( theMaxDelay ) ) { return -1;	}

	workerNotice = theMessage;
	// To be run on the FX Thread !
	Platform.runLater(ctrlClerc::notifyDownloadFatalMessage);

	// Now wait for the release of the Flag by the FX Thread, until the delay expires
	int leftTime = 1000 * theMaxDelay;
	do {
	   if ( ! runLaterISSET() ) { return 1; }
	   getAPauseOf(701);
	   leftTime-= 701;
	} while (leftTime > 0);

	return 0;
   }


   private int waitForFlagRelease( int theMaxDelay )
    {
	int leftTime = 1000 * theMaxDelay;
	do {
	   if ( ! runLaterISSET() ) { return 1; }
	   getAPauseOf(701);
	   leftTime-= 701;
	} while (leftTime > 0);

	return 0;
   }
}
