﻿
==========================================
FlightGearGardener - Version 02 - Jan 2018
==========================================
ConfigReadme.txt
================

FlightGearGardener will not run without a few configuration parameters, which are loaded at Startup time from
a dedicated config file, actually a java xml "Property" file. This file MUST be located in an 
application-specific folder "FLIGHTGEARGardener", and MUST be named "sysContext.xml", so that FlightGearGardener
will search for a ...\FLIGHTGEARGardener\sysContext.xml resourse somewhere (.../FLIGHTGEARGardener/sysContext.xml 
on Unix).

Provided you have already downloaded/copied the various files as explained in the AppGeneralReadMe, your options 
for instructing FlightGearGardener where to find the sysContext.xml resource are roughly as follows:


1. Minimal :
	Just apply the following changes in the herewith incuded "FG_GardenerV02\Z_Javapps\z_Launchpad.xml" and 
		"FG_GardenerV02\Config\FLIGHTGEARGardener\sysContext.xml" files (as mentionned in both of them):
			
		"	================================================================
		"	TAKE CARE OF THE FOLLOWING CHANGES TO BE APPLIED BEFORE ANY RUN:
		"	==========================
	 	"	1. Hereafter, path syntax targets a Windows context: Please apply required changes (separator, 
		"		root name...) for non-Windows OSes);
		"	2. Please change $$!$$ into your account name (so that "C:\Users\$$!$$" equals your UserHome).
				
	Then double-click the FlightGearGardener.jar provided in FG_Bin (on Windows, you may need to associate 
		.jar execution with your local Java jvm... On Unix, you may need to make FlightGearGardener.jar 
		executable first and/or run it as such... as usual). 
	
	FlightGearGardener must start, using default locations as stated in sysContext.xml...
	
		
2. Medium, "à la Windows" ...
	a- Don't create a specific Z_Javapps folder, don't use/copy the z_Launchpad.xml redirection file. This will
		instruct FlightGearGardener to search its configuration file, by default, in:
		
						userHomeDir --> AppData --> Roaming --> MimoApps --> FLIGHTGEARGardener ;
						
	b- In your "userHomeDir" (usually C:\Users\YourAccountName on Windows, or /home/YourAccountName on Unix) :
		go to AppData\Roaming, and (on Windows) create there the folders MimoApps\FLIGHTGEARGardener, 
		or (on Unix) create the folders suite AppData/Roaming/MimoApps/FLIGHTGEARGardener;
	c- Copy there the standard "sysContext.xml" file herewith provided, and possibly edit the entries 
			* "Log_Location", -- an existing folder where the Logs will be written, 
			* "BackgroundMap_Location", -- an existing folder where the Shapefiles have been copied,
			* "Terrasync_Folder", -- an existing folder where the FileChooser will be opened by default ; 
		Note that the folder paths are expected to be absolute, and well formed (using local system separator), 
		and updated for account name, as explained in 1. above. 
	d- Copy the 3 Shapefiles to the just specified BackgroundMap_Location folder (if changed);
	e- Copy the content of FG_bin to any place that suits your needs. Note that both FlightGearGardener.jar AND
		its companion "lib" folder must reside in the same place ! Then launch FlightGearGardener.jar as in
		1. above...
	f- When this is working, you may further change some other properties. 
		The single one that could NOT BE CHANGED (without FlightGear instruction) is the "Terrasync_DNSLookupName". 
		The "Shapefile_Name" may be modified as long as you maintain consistency with your prefered 
		shapefiles (which must be "ESRI-compliant" - Note that none, other than the NaturalEarth ones herewith 
		included, have been tested...).
		The "Terrain_FRESHGAP" may be changed at any time (value between 10 and maxInt) to fine-tune your sync
		freshness (new value will get used at next start).
		Read some more info in the companion sysContextDoc.txt file.
		
		
3. Using complete relocation ... (including a little change in the UNIX default Configuration directory)
	- In the folder "userHomeDir\AppData\Roaming" (existing by default) on Windows, or "userHomeDir/.config" on
		Unix, create a "Z_Javapps" folder (readable, of course), and copy there the herewith 
		supplied "z_Launchpad.xml" Properties file (the launchpad redirection file); 
	- Edit this file single entry to mention the full path of your target configuration folder (... which will 
		take over the role of the "minimal" option "userHomeDir --> FG_GardenerV02 --> Config");
	- Then, in this folder, create a folder FLIGHTGEARGardener, and follows the next steps as in 2.c- above.
	
	
	