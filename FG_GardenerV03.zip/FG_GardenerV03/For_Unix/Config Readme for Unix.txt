﻿
==========================================
FlightGearGardener - Version 03 - Jan 2018
==========================================
Config Readme for Unix.txt
==========================

FlightGearGardener will not run without a few configuration parameters, which are loaded at Startup time from
a dedicated config file, actually a java xml "Property" file. This file MUST be located in an 
application-specific folder "FLIGHTGEARGardener", and MUST be named "sysContext.xml", so that FlightGearGardener
will search for a .../FLIGHTGEARGardener/sysContext.xml resourse somewhere.

Provided you have already read the User Guide "Generic Configuration Guide" the following is just a UNIX-targeted 
objects specialisation, to validate the installation results.

In the following, let's use "abcdxyz" as a placeHolder for your REAL UserHomeDir folder name. So, on UNIX 
Platforms we will use as the "standard configuration directory" path:
				</home/abcdxyz/.config>

In case you opted for the type B.1. installation: 
			Quick install for testing FlightGearGardener with no further customization, USING RELOCATION:
		
you must end up with the following objects:

	a. FG_GardenerV03 is a folder in your HomeDir, with path:
				</home/abcdxyz/FG_GardenerV03>
				
	b. There is a <Z_Javapps> folder in your Platform standard configuration directory, with path:				
				</home/abcdxyz/.config/Z_Javapps>
				
	c. There is a <z_Launchpad.xml> file in <Z_Javapps> with path:			
				</home/abcdxyz/.config/Z_Javapps/z_Launchpad.xml>	
				
	d. This file has been edited to change the occurence of "$$!$$" into <abcdxyz>; the resulting entry
		looks as follows:
				<entry key="JAVAPPS_Launchpad">/home/abcdxyz/FG_GardenerV03/Config</entry>	
				
	e. This folder contains the <FLIGHTGEARGardener> folder, which in turn contains the <sysContext.xml> 
		file, copied from For_Unix, with full path:
				</home/abcdxyz/FG_GardenerV03/Config/FLIGHTGEARGardener/sysContext.xml>	
				
	f. This file has been edited to change ALL occurences of "$$!$$" into your specific HomeDir folder
		name <abcdxyz>; for instance those lines are looking now like (other lines unchanged):
				<!-- Entries relative to Loging -->
					<entry key="Log_Location">/home/abcdxyz/FG_GardenerV03/ZZ-Logs</entry>
					...
				<!-- Entries relative to Geo Files -->
					<entry key="BackgroundMap_Location">/home/abcdxyz/FG_GardenerV03/ShapeFiles</entry>
					...
				<!-- Entries relative to Terrasync -->
					<entry key="Terrasync_Folder">/home/abcdxyz/FG_GardenerV03/DefaultTerrasync</entry>
					...
		

In case you opted for the type B.2. installation:
			Quick install for testing FlightGearGardener with no further customization, NOT USING RELOCATION:
	
you must end up with the following objects:

	a. FG_GardenerV03 is a folder in your HomeDir, with path:
				</home/abcdxyz/FG_GardenerV03>
				
	b. A <MimoApps> folder created in your Platform standard configuration directory, with path:				
				</home/abcdxyz/.config/MimoApps>
				
	c. A <FLIGHTGEARGardener> folder created there, with path:				
				</home/abcdxyz/.config/MimoApps/FLIGHTGEARGardener>
				
	d. A copy of the <sysContext.xml> file copied there from For_Unix, with full path:
				</home/abcdxyz/.config/MimoApps/FLIGHTGEARGardener/sysContext.xml>	
				
	f. This file has been edited, exactly as above.
	
	
	