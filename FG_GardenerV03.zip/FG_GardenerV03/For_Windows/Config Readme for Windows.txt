﻿
==========================================
FlightGearGardener - Version 03 - Jan 2018
==========================================
Config Readme for Windows.txt
=============================

FlightGearGardener will not run without a few configuration parameters, which are loaded at Startup time from
a dedicated config file, actually a java xml "Property" file. This file MUST be located in an 
application-specific folder "FLIGHTGEARGardener", and MUST be named "sysContext.xml", so that FlightGearGardener
will search for a ...\FLIGHTGEARGardener/sysContext.xml resourse somewhere.

Provided you have already read the User Guide "Generic Configuration Guide" the following is just a WINDOWS-targeted 
objects specialisation, to validate the installation results.

In the following, let's use "abcdxyz" as placeHolder for your UserHomeDir folder name. So, on WINDOWS Platforms 
we will use as the "standard configuration directory" path:
				<C:\Users\abcdxyz\AppData\Roaming>

In case you opted for the type B.1. installation: 
			Quick install for testing FlightGearGardener with no further customization, USING RELOCATION:
		
you must end up with the following objects:

	a. FG_GardenerV03 is a folder in your HomeDir, with path:
				<C:\Users\abcdxyz\FG_GardenerV03>
				
	b. There is a <Z_Javapps> folder in your Platform standard configuration directory, with path:				
				<C:\Users\abcdxyz\AppData\Roaming\Z_Javapps>
				
	c. There is a <z_Launchpad.xml> file in this <Z_Javapps> folder, with path:			
				<C:\Users\abcdxyz\AppData\Roaming\Z_Javapps\z_Launchpad.xml>	
				
	d. This file has been edited to change the occurence of "$$!$$" into <abcdxyz>; the resulting entry
		looks as follows:
				<entry key="JAVAPPS_Launchpad">C:\Users\abcdxyz\FG_GardenerV03\Config</entry>	
				
	e. This folder contains the <FLIGHTGEARGardener> folder, which in turn contains the <sysContext.xml> 
		file copied from For_Windows, with full path:
				<C:\Users\abcdxyz\FG_GardenerV03\Config\FLIGHTGEARGardener\sysContext.xml>	
				
	f. This file has been edited to change ALL occurences of "$$!$$" into your specific HomeDir folder
		name <abcdxyz>; for instance those lines are looking now like (other lines unchanged):
				<!-- Entries relative to Loging -->
					<entry key="Log_Location">C:\Users\abcdxyz\FG_GardenerV03\ZZ-Logs</entry>
					...
				<!-- Entries relative to Geo Files -->
					<entry key="BackgroundMap_Location">C:\Users\abcdxyz\FG_GardenerV03\ShapeFiles</entry>
					...
				<!-- Entries relative to Terrasync -->
					<entry key="Terrasync_Folder">C:\Users\abcdxyz\FG_GardenerV03\DefaultTerrasync</entry>
					...
		

In case you opted for the type B.2. installation:
			Quick install for testing FlightGearGardener with no further customization, NOT USING RELOCATION:
	
you must end up with the following objects:

	a. FG_GardenerV03 is a folder in your HomeDir, with path:
				<C:\Users\abcdxyz\FG_GardenerV03>
				
	b. A <MimoApps> folder created in your Platform standard configuration directory, with path:				
				<C:\Users\abcdxyz\AppData\Roaming\MimoApps>
				
	c. A <FLIGHTGEARGardener> folder created there, with path:				
				<C:\Users\abcdxyz\AppData\Roaming\MimoApps\FLIGHTGEARGardener>
				
	d. A copy of the <sysContext.xml> file copied there from For_Windows, with full path:
				<C:\Users\abcdxyz\AppData\Roaming\MimoApps\FLIGHTGEARGardener\sysContext.xml>	
				
	e. This file has been edited, exactly as above.
	
	
	